﻿using System.Collections;
using System.Collections.Generic;

public class PosingNote
{
    public float judgeTime;
    public string posingType;
    public bool isTarget = false;
}
